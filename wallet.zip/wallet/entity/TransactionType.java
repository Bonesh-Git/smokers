package com.example.wallet.entity;

public enum TransactionType {
    DEBIT,CREDIT
    //bedehkar va bestankar(variz va bardasht)
}
