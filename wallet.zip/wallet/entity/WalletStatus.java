package com.example.wallet.entity;

public enum WalletStatus {
    BLOCKED,BANNED,NORMAL,CLOSED
    //MasdodShode,KhodemonBastimesh,Adi,WalletVojodNadare
}
