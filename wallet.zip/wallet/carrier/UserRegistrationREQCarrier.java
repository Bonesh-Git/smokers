package com.example.wallet.carrier;

public record UserRegistrationREQCarrier (String fullName,String mobileNumber,String username, String password){
}
