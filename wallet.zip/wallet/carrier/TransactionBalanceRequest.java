package com.example.wallet.carrier;

import java.util.UUID;

public record TransactionBalanceRequest (UUID walletId){
}
