package com.example.wallet.carrier;

import java.util.List;
import java.util.UUID;

public record TranListResCarrier (List<UUID> lst) {
}
