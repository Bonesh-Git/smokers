package com.example.wallet.carrier;

public record TransactionGetBalanceResp (Long amount){
}
