package com.example.wallet.carrier;

public record ExceptionCarrier(int code, String message){

}

