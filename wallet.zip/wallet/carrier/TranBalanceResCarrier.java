package com.example.wallet.carrier;

public record TranBalanceResCarrier(Long balance) {
}
