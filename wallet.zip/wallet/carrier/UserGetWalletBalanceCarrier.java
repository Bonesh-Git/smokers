package com.example.wallet.carrier;

public record UserGetWalletBalanceCarrier (String username){
}
