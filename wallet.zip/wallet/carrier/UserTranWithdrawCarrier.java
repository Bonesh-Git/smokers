package com.example.wallet.carrier;

public record UserTranWithdrawCarrier (Long amount){
}
