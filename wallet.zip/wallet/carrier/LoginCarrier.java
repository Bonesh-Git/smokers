package com.example.wallet.carrier;

public record LoginCarrier (String username, String password) {

}
