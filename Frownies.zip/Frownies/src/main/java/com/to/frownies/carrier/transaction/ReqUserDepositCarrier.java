package com.to.frownies.carrier.transaction;

public record ReqUserDepositCarrier(Long amount) {
}
