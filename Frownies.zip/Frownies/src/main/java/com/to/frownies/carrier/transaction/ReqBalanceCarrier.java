package com.to.frownies.carrier.transaction;

import java.util.UUID;

public record ReqBalanceCarrier (UUID walletId){
}
