package com.to.frownies.carrier.user;

import com.to.frownies.entity.User;

public record ResModifyCarrier (User user){
}
