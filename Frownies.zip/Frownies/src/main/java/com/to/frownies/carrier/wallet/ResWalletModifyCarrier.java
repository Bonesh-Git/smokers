package com.to.frownies.carrier.wallet;

import com.to.frownies.entity.Wallet;

public record ResWalletModifyCarrier(Wallet wallet) {
}
