package com.to.frownies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrowniesApplication {

    public static void main(String[] args) {
        SpringApplication.run(FrowniesApplication.class, args);
    }

}
