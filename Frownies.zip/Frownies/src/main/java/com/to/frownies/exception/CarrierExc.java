package com.to.frownies.exception;

public record CarrierExc(int code, String message) {
}
