package com.to.frownies.carrier.transaction;

public record ReqUserTransferCarrier(String destinationUsername, Long amount){
}
